import React from 'react';
import Hometable from '../../components/HompageTable/Hometable';

const Home = () => {
    return (
        <div className='max-w-7xl mx-auto min-h-[100vh]'>
            <Hometable></Hometable>
        </div>
    );
};

export default Home;